void append2screen(char * str, int color);
