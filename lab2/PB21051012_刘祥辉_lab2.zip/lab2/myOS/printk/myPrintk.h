int myPrintk(int color,const char *format, ...);
int myPrintf(int color,const char *format, ...);