#ifndef __TYPES__H__
#define __TYPES__H__
typedef int size_t;
#define short int
#endif