#include "../myOS/userInterface.h"
#include "shell.h"
#include "../myOS/include/myPrintk.h"
#include "../myOS/include/task.h"

int t0, t1, t2;
extern void delay();

void test0(void)
{
	myPrintf(0x7, "***Task 0***\n");

	int time_flag = 0;
	while (time_flag < t0)
	{
		myPrintf(0x7, "task0 exe: %d/%d\n", time_flag + 1, t0);
		time_flag++;
		delay();
	}
	return;
}

void test1(void)
{

	myPrintf(0x7, "***Task 1***\n");
	int time_flag = 0;
	while (time_flag < t1)
	{
		myPrintf(0x7, "task1 exe: %d/%d\n", time_flag + 1, t1);
		time_flag++;
		delay();
	}

	return;
}

void test2(void)
{
	myPrintf(0x7, "***Task 2***\n");

	int time_flag = 0;
	while (time_flag < t2)
	{
		myPrintf(0x7, "task2 exe: %d/%d\n", time_flag + 1, t2);
		time_flag++;
		delay();
	}

	return;
}

void shell(void)
{
	myPrintk(0x7, "****start shell****\n");
	startShell();
	return;
}

void Time_set(int tsk0, int tsk1, int tsk2)
{
	t0 = tsk0;
	t1 = tsk1;
	t2 = tsk2;
	return;
}