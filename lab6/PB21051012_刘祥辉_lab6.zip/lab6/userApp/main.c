#include "../myOS/userInterface.h"   //interface from kernel
#include "shell.h"
#include "memTestCase.h"


void startShell(void);
void initShell(void);
void tskStart(int tskIndex);
void memTestCaseInit(void);
int createTsk(void (*tskBody)(void), unsigned int arrt, unsigned int exet, unsigned int prior);
void tskEnd(void);
extern void Time_set(int tsk0, int tsk1, int tsk2);
extern void test0(void);
extern void test1(void);
extern void test2(void);
extern void shell(void);

void wallClock_hook_main(void){
	int _h, _m, _s;
	char hhmmss[]="hh:mm:ss\0\0\0\0";

	getWallClock(&_h,&_m,&_s);
	sprintf(hhmmss,"%02d:%02d:%02d",_h,_m,_s);
	put_chars(hhmmss,0x7E,24,72);
}

void doSomeTestBefore(void){		
	setWallClock(18,59,59);		//set time 18:59:59
    	setWallClockHook(&wallClock_hook_main);
}

void Tskstart(int tid0,int tid1,int tid2,int tid_shell){
	tskStart(tid0);
	tskStart(tid1);
	tskStart(tid2);
	tskStart(tid_shell);
}
// init task 入口
void myMain(void) {
     clear_screen();

     //myPrintf(0x2,"debug_myMain_begin......\n");

     doSomeTestBefore();
     
    myPrintf(0x07, "********************************\n");
	myPrintf(0x07, "*         INIT   INIT !        *\n");
	myPrintf(0x07, "********************************\n");

     //#error "TODO: 初始化 shell 并创建 shell task"
     
     initShell();
     memTestCaseInit();

     //myPrintf(0x2,"debug_myMain_end......\n");

	int tid_shell ,tid0,tid1,tid2;
	if(type==PRIO){
		Time_set(3, 5, 3);
		tid_shell = createTsk(shell, 12, 0xFFFF, 0);
		tid0 = createTsk(test0, 2, 3, 5);
		tid1 = createTsk(test1, 4, 5, 3);
		tid2 = createTsk(test2, 5, 3, 1);
	}
	else if(type==SJF){
		Time_set(3, 4, 2);
		tid_shell = -1;
		tid0 = createTsk(test0, 3, 3, 1);
		tid1 = createTsk(test1, 3, 4, 3);
		tid2 = createTsk(test2, 5, 2, 2);
	}
	Tskstart(tid0,tid1,tid2,tid_shell);
	myPrintf(0x07, "**********Finish!*********\n");
     return;
}
