#include "include/i8253.h"
#include "include/i8259.h"
#include "include/irq.h"
#include "include/uart.h"
#include "include/vga.h"
#include "include/mem.h"
#include "include/task.h"
#include "include/myPrintk.h"

unsigned int is_schedule;
int num = 0;
extern int InterruptTime;
void initShell(void);
void startShell(void);

void osStart(void){
     //pressAnyKeyToStart(); // prepare for uart device
     init8259A();
     init8253();
     enable_interrupt();
     clear_screen();

     //#error "TODO: 初始化内存和任务管理"

	pMemInit();  //after this, we can use kmalloc/kfree and malloc/free

	myPrintk(0x7, "START RUNNING......\n");
	myPrintk(0x7, "[0]: shell\n");
	myPrintk(0x7, "[1]: SJF\n");
	myPrintk(0x7, "[2]: PRIO\n");
	myPrintk(0x7,"please choose a function to finish pross scheduling\n");
	num = uart_get_char();

	clear_screen();

	if (num == '0'){
		initShell();
		startShell();
	}
	else
	{
		is_schedule=1;
		InterruptTime=0;
		switch (num)
		{
		case '1':
			type = SJF;
			break;
		case '2':
			type = PRIO;
			break;
		}
		TaskManagerInit();
	}

	myPrintk(0x7, "STOP RUNNING......ShutDown\n");
	while (1);
}
