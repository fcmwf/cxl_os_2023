#ifndef __STRING_H__
#define __STRING_H__

int Mystrcmp(unsigned char *str1, unsigned char *str2);
int Mystrncpy(unsigned char *src, unsigned char *dest, unsigned int n);

#endif