#include "../include/task.h"
#include "../include/myPrintk.h"
#include "../include/kmalloc.h"

void schedule(void);
void destroyTsk(int takIndex);

#define TSK_RDY 0        //表示当前进程已经进入就绪队列中
#define TSK_WAIT -1      //表示当前进程还未进入就绪队列中
#define TSK_RUNING 1     //表示当前进程正在运行
#define TSK_NONE 2       //表示进程池中的TCB为空未进行分配

#define NULL (void*)0
#define TRUE  1
#define FALSE 0

extern int InterruptTime;
int waittime;
int tid_used = 0;

typedef struct myTCB {
     unsigned long tid;         /* 进程ID */ 
     unsigned long *stack_top, *stack_end;        /* 栈顶指针 */
     states task_state;   /* 进程状态 */
     void (*entry)(void);  /*进程的入口地址*/
     unsigned long runtime;        //运行时间
     unsigned long leftTime;       //调度时间
     unsigned long priority;       //优先级
     unsigned long exeTime;        //总执行时间
     unsigned long arrTime;        //到达时间
     struct myTCB * next;           /*下一个TCB*/
} myTCB;

typedef struct rdyQueueFCFS{
     myTCB * head;
     myTCB * tail;
}Queue;

Queue Queue_wait,Queue_ready,Queue_run;

myTCB tcbPool[TASK_NUM];//进程池的大小设置

myTCB * idleTask;                /* idle 任务 */
myTCB * currentTask;             /* 当前任务 */

void tskEnd();
void context_switch(unsigned long **prevTskStkAddr, unsigned long *nextTskStk);
void Sch_Queue(Queue *handler);

//////////////////////////////////////////////////
//队列管理函数
//就绪队列的结构体
typedef struct line{
     myTCB * head;
     myTCB * tail;
     myTCB * idleTsk;
} line;

line rqFCFS;

//初始化就绪队列（需要填写）
void rqFCFSInit(myTCB* idleTsk) {//对rqFCFS进行初始化处理
     rqFCFS.idleTsk = idleTsk;
     rqFCFS.head    = NULL;
     rqFCFS.tail    = NULL;
}

//如果就绪队列为空，返回True（需要填写）
int rqFCFSIsEmpty(void) {//当head和tail均为NULL时，rqFCFS为空
     if(rqFCFS.head==NULL&&rqFCFS.tail==NULL)
          return TRUE;
     else 
          return FALSE;
}

//获取就绪队列的头结点信息，并返回（需要填写）
myTCB * nextFCFSTsk(void) {//获取下一个Tsk
     return rqFCFS.head;
}

//将一个未在就绪队列中的TCB加入到就绪队列中（需要填写）
void tskEnqueueFCFS(myTCB *tsk) {//将tsk入队rqFCFS
     tsk->next = NULL;
     if(rqFCFSIsEmpty()){
          rqFCFS.head = tsk;
          rqFCFS.tail = tsk;
     }
     else {
          rqFCFS.tail->next = tsk;
          rqFCFS.tail = tsk;
     }
     return;
}

//将就绪队列中的TCB移除（需要填写）
void tskDequeueFCFS(myTCB *tsk) {//rqFCFS出队
     if(rqFCFS.head==rqFCFS.tail){
          if(rqFCFS.head==NULL) return;
          else{
               rqFCFS.head = NULL;
               rqFCFS.tail = NULL;
          }
     }
     else{
          rqFCFS.head = rqFCFS.head->next;
     }
     return;
}

myTCB *ReturnHead(Queue *handler)
{
	if (handler->head == 0)
		return idleTask;
	else
		return handler->head;
}

void Enqueue(Queue *handler, myTCB *tsk)
{
	if (handler->head == 0)
	{
		handler->head = handler->tail = tsk;
		handler->tail->next = 0;
		return;
	}
	handler->tail->next = tsk;
	handler->tail = tsk;
	tsk->next = 0;
	return;
}

myTCB *Dequeue(Queue *handler)
{
	myTCB *TCB = handler->head;
	if (handler->head == 0)
		return TCB;
	if (handler->head == handler->tail)
	{
		handler->head = handler->tail = 0;
		return TCB;
	}
	handler->head = (handler->head)->next;
	return TCB;
}

myTCB *QueueDestroy(Queue *handler, int tid)
{
	myTCB *p = handler->head;
	if (p == 0)
		return 0;
	if (p->tid == tid)
	{
		if (p == handler->tail)
			handler->head = handler->tail = 0;
		else
		{
			handler->head = p->next;
			p->next = 0;
		}
		return p;
	}
	while (p->next != 0)
	{
		if (p->next->tid == tid)
		{
			myTCB *q = p->next;
			p->next = q->next;
			q->next = 0;
			if (q == handler->tail)
				handler->tail = p;
			return q;
		}
		p = p->next;
	}
}
int result;
void QueueSort( Queue*handler, ScheduleType schedule_type)  //按照相应调度要求排序
{
	myTCB temp;
	myTCB *handl_ps1 = handler->head, *handl_ps2 = handl_ps1;
	while (handl_ps1->next != 0)
	{
		handl_ps2 = handl_ps1->next;
		while (handl_ps2 != 0)
		{
               switch (schedule_type){
                    case PRIO:
                         {
                              if (handl_ps1->priority > handl_ps2->priority)
                                   result =  -1;
                              else if (handl_ps1->priority == handl_ps2->priority)
                                   result =  0;
                              else if (handl_ps1->priority < handl_ps2->priority)
                                   result =  1;
                         }
                         break;
                    case SJF:
                         {
                              if (handl_ps1->exeTime > handl_ps2->exeTime)
                                   result = -1;
                              else if (handl_ps1->exeTime == handl_ps2->exeTime)
                                   result =  0;
                              else if (handl_ps1->exeTime < handl_ps2->exeTime)
                                   result =  1;
                         }
                         break;
                    }
			if (result < 0){
				temp = *handl_ps2;
				myTCB *tmp = handl_ps2->next;
				*handl_ps2 = *handl_ps1;
				handl_ps2->next = tmp;
				tmp = handl_ps1->next;
				*handl_ps1 = temp;
				handl_ps1->next = tmp;
			}
			handl_ps2 = handl_ps2->next;
		}
		handl_ps1 = handl_ps1->next;
	}
	return;
}

///////////////////////////////////////////////////////////////
Queue *Handler_wait = &Queue_wait;
Queue *Handler_ready = &Queue_ready;
Queue *Handler_run = &Queue_run;

void idleTskBody(void)
{
	while (Handler_ready->head == 0);
	return;
}
//初始化栈空间（不需要填写）
void stack_init(unsigned long **stk, void (*task)(void)){
     *(*stk)-- = (unsigned long) tskEnd;       //高地址
     *(*stk)-- = (unsigned long) task;       //EIP
     *(*stk)-- = (unsigned long) 0x0202;     //FLAG寄存器

     *(*stk)-- = (unsigned long) 0xAAAAAAAA; //EAX
     *(*stk)-- = (unsigned long) 0xCCCCCCCC; //ECX
     *(*stk)-- = (unsigned long) 0xDDDDDDDD; //EDX
     *(*stk)-- = (unsigned long) 0xBBBBBBBB; //EBX

     *(*stk)-- = (unsigned long) 0x44444444; //ESP
     *(*stk)-- = (unsigned long) 0x55555555; //EBP
     *(*stk)-- = (unsigned long) 0x66666666; //ESI
     *(*stk)   = (unsigned long) 0x77777777; //EDI

}
myTCB **return_Addr;
int stack_ptr = 0;
Queue Queue_dready;
Queue *Handler_dready = &Queue_dready;
//进程池中一个未在就绪队列中的TCB的开始（不需要填写）
void tskStart(int tskIndex)
{
	myTCB *TCB = QueueDestroy(Handler_wait, tskIndex);
	if (TCB == 0)
		return;
	Enqueue(Handler_dready, TCB);
	QueueSort(Handler_dready, type);

	return;
}


//以tskBody为参数在进程池中创建一个进程，并调用tskStart函数，将其加入就绪队列（需要填写）
int createTsk(void (*tskBody)(void), unsigned int ART, unsigned int ET, unsigned int PRI)
{
	myTCB *TCB = (myTCB *)kmalloc(sizeof(TCB));

	TCB->entry = tskBody;
	TCB->arrTime = ART;
	TCB->priority = PRI;
	TCB->exeTime = ET;
	TCB->stack_end = (void *)kmalloc(STACK_SIZE);
	TCB->stack_top = TCB->stack_end + STACK_SIZE - STACK_RESERVE;
	TCB->tid = tid_used;
	tid_used++;
	stack_init((unsigned long **)&(TCB->stack_top), tskBody);
	Enqueue(Handler_wait, TCB);

	return TCB->tid;
}

//以takIndex为关键字，在进程池中寻找并销毁takIndex对应的进程（需要填写）
void destroyTsk(int tid)
{
	if (tid == idleTask->tid)
		return;
	myTCB *TCB = QueueDestroy(Handler_wait, tid);
	if (TCB == 0)
		TCB = QueueDestroy(Handler_ready, tid);
	if (TCB == 0)
		TCB = QueueDestroy(Handler_run, tid);
	if (TCB == 0)
		return;
	kfree((unsigned long)(TCB->stack_end));
	kfree((unsigned long)TCB);
	return;
}

unsigned long **prevTSK_StackPtr;
unsigned long *nextTSK_StackPtr;

//切换上下文（无需填写）
void context_switch(unsigned long **prevTskStkAddr, unsigned long *nextTskStk)
{
	prevTSK_StackPtr = prevTskStkAddr;
	nextTSK_StackPtr = nextTskStk;
	CTX_SW(prevTSK_StackPtr,nextTSK_StackPtr);
}


//调度算法（无需填写）
void Schedule()
{
	return Sch_Queue(Handler_ready);
}

//进入多任务调度模式(无需填写)
unsigned long BspContextBase[STACK_SIZE];
unsigned long *BspContext;

void startMultitask(void) {
     BspContext = BspContextBase + STACK_SIZE -1;
	currentTask = 0;
	Schedule();
	return;
}

//进程池中一个在就绪队列中的TCB的结束（不需要填写）
void Queue_Detec(myTCB *TCB){
	if (TCB->tid == 4 )
	{
		Dequeue(Handler_run);
		tskStart(idleTask->tid);
		Schedule();
	}
	return;
}
void Queue_sch_pro(){
	Dequeue(Handler_ready);
	Enqueue(Handler_run, currentTask);
}
void tskEnd()
{
	myTCB *TCB = Dequeue(Handler_run);
	if (TCB == 0)
		return;

	Queue_Detec(TCB);
	context_switch((unsigned long **)&(currentTask->stack_top), BspContext);
	return;
}

extern int is_schedule;
void Queue_process(){
	if (currentTask == idleTask)
	{
		createTsk(idleTskBody, 0x7FFFFFFF, 1, 0);
		idleTask = Handler_wait->tail;
	}
}
//准备进入多任务调度模式(无需填写)
void TaskManagerInit(void) {
     // 初始化进程池（所有的进程状态都是TSK_NONE）
     int i;
     myTCB * thisTCB;
     for(i=0;i<TASK_NUM;i++){//对进程池tcbPool中的进程进行初始化处理
          thisTCB = &tcbPool[i];
          thisTCB->tid = i;
          thisTCB->stack_top = thisTCB->stack_end+STACK_SIZE-1;//将栈顶指针复位
          thisTCB->task_state = TSK_NONE;//表示该进程池未分配，可用
          thisTCB->entry = (void*)0;
          if(i==TASK_NUM-1){
               thisTCB->next = (void *)0;
          }
          else{
               thisTCB->next = &tcbPool[i+1];
          }
     }
     //创建idle任务
     int tid_init ;
	 tid_init = createTsk(initTskBody, 0, 1, 0);
     //创建init任务
     int tid_idle ;
	 tid_idle = createTsk(idleTskBody, 100, 1, 0);
     	idleTask = Handler_wait->tail;
	tskStart(tid_init);

	myTCB *TCB = QueueDestroy(Handler_dready, tid_init);
	Enqueue(Handler_ready, TCB);

     return_Addr = (myTCB **)kmalloc(10 * sizeof(myTCB *));

     //进入多任务状态
     myPrintk(0x2,"START MULTITASKING......\n");
     startMultitask();
     myPrintk(0x2,"STOP MULTITASKING......SHUT DOWN\n");
}

void Sch_Queue(Queue *handler)
{
	while (1)
	{
		myTCB *nextTask = ReturnHead(Handler_ready);
		nextTask->task_state = RUNNING;
		currentTask = nextTask;
		Queue_sch_pro();
		unsigned long **p = &BspContext;

		context_switch(p, currentTask->stack_top);
		Queue_process();
	}
	return;
}

void Queue_manager(){
	myTCB *TCB = 0;
	if (is_schedule == 0)
		return;
	if (currentTask != 0 && currentTask != idleTask && currentTask->exeTime > 0)
		currentTask->exeTime--;
		
	do{
		TCB = ReturnHead(Handler_dready);
		if (TCB == idleTask)
			break;
		if (TCB->arrTime <= InterruptTime)
		{
			Dequeue(Handler_dready);
			Enqueue(Handler_ready, TCB);
			QueueSort(Handler_ready, type);
		}
	} while (TCB->arrTime <= InterruptTime);
	myTCB *nextTCB = ReturnHead(Handler_ready);

	if (nextTCB == idleTask)
		return;

	if(type==PRIO){
		if (currentTask->priority > nextTCB->priority)
		{
			unsigned long **p = &BspContext;

			QueueDestroy(Handler_run, currentTask->tid);
			Dequeue(Handler_ready);
			Enqueue(Handler_run, nextTCB);
			Enqueue(Handler_ready, currentTask);
			QueueSort(Handler_ready, type);

			myTCB *temp = currentTask;

			currentTask = nextTCB;
			context_switch(&BspContext, currentTask->stack_top);
			currentTask = Dequeue(Handler_ready);
			Enqueue(Handler_run, currentTask);
		}
	}
	return;
}