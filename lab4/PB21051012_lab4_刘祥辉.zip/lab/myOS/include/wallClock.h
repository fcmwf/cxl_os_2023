#ifndef __WALLCLOCK_H__
#define __WALLCLOCK_H__

void setWallClock(int h, int m, int s);
void getWallClock(int *h, int *m, int *s);

#endif
