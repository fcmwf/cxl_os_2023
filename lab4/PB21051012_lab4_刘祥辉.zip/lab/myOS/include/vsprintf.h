#ifndef __STRING_H__
#define  __STRING_H__

#include <stdarg.h>
int vsprintf(char *buf, const char *fmt, va_list args);

#endif
