#ifndef __USERINTERFACE_H__
#define __USERINTERFACE_H__

#include "vga.h"
#include "uart.h"
#include "string.h"
#include "myPrintk.h"
#include "malloc.h"

#include "kmalloc.h"
#include "mem.h"

#endif